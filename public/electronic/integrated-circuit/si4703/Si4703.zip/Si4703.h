#ifndef SI4703_H
#define SI4703_H

#include <stdbool.h>
#include <stdint.h>

/* Powerup + 2-wire bus setup + register defaults (BAND=EU, SPACE=100 kHz,
 * VOL=15, DE=50us, MONO=1). Returns false if I2C handshake fails. */
bool Si4703_init(void);

/* Tune to a frequency in MHz×10 (875..1080 with BAND=00/SPACE=01).
 * Returns false if STC never asserts (crystal/ENABLE/hardware). */
bool Si4703_tune(uint16_t freq_x10);

/* Sweeps 87.5–108.0 MHz and prints over UART the channels with RSSI >= rssi_min. */
void Si4703_scan(uint8_t rssi_min);

/* Verbose diagnostic: tries a single tune at freq_x10 and dumps over UART
 * the state of the relevant registers before/during/after. */
void Si4703_diag_tune(uint16_t freq_x10);

/* Refreshes the local copy of the 16 registers by reading from the chip. */
bool Si4703_refresh(void);

/* Moves frequency by ±0.1 MHz with wrap at band edges. */
bool Si4703_freq_up(void);
bool Si4703_freq_down(void);

/* Hardware seek. up=true seeks upward, false downward. Returns true if a
 * station was found; false on SEEK FAIL (band exhausted). */
bool Si4703_seek(bool up);

/* Volume 0..15 (clamped). */
void    Si4703_set_volume(uint8_t vol);
uint8_t Si4703_volume(void);
void    Si4703_volume_up(void);
void    Si4703_volume_down(void);

/* RDS demodulation enable/disable (SYSCONFIG1.RDS). Resets PS/RT buffers. */
void Si4703_set_rds(bool on);

/* Reads STATUSRSSI; if RDSR=1, parses one group into the PS/RT buffers.
 * Returns true when a new group was consumed. Call frequently from the loop. */
bool Si4703_rds_poll(void);

/* Returns 8-char PS name and 64-char Radio Text (null-terminated). Unset
 * positions are spaces until the corresponding groups arrive. */
const char *Si4703_rds_ps(void);
const char *Si4703_rds_rt(void);

/* True when the RDS decoder is synchronized to the bitstream. */
bool Si4703_rds_synced(void);

/* Block A error rate (0=none, 1=1-2 corr, 2=3-5 corr, 3=uncorrectable). */
uint8_t Si4703_rds_blera(void);

/* Accessors on the local copy (valid after init/tune/scan/refresh). */
uint16_t Si4703_device_id(void);
uint16_t Si4703_chip_id(void);
uint16_t Si4703_freq_x10(void);     /* derived from READCHAN + 87.5 MHz base */
uint8_t  Si4703_rssi(void);
bool     Si4703_stereo(void);

#endif
