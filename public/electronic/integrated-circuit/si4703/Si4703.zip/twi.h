#ifndef TWI_H
#define TWI_H

#include <stdbool.h>
#include <stdint.h>

/* TWI0 master @ 100 kHz, ALT2 (PC2/PC3) at F_CPU=24 MHz. */
void TWI0_init(void);

/* Master write: START + (addr<<1|W) + len bytes + STOP.
 * Returns false on NACK, ARBLOST or BUSERR. */
bool TWI_write(uint8_t addr, const uint8_t *data, uint16_t len);

/* Master read: START + (addr<<1|R) + len bytes (ACK on all but the last) + STOP.
 * Returns false on ARBLOST or BUSERR. */
bool TWI_read(uint8_t addr, uint8_t *data, uint16_t len);

#endif
