#ifndef UART_H
#define UART_H

#include <stdbool.h>

/* USART1 @ 115200 8N1, PC0=TX, PC1=RX. */
void UART1_init(void);
void UART1_write(char c);
void UART1_send_string(const char *s);

/* Non-blocking reception. */
bool UART1_rx_available(void);
char UART1_read(void);

#endif
