/*
 * Si4703 FM tuner — AVR128DA28 bare-metal, 2-wire (I2C) mode.
 *
 * References:
 *   - Si4702/03-C19 Datasheet (Skyworks/Silicon Labs)
 *   - AN230 Si4700/01/02/03 Programming Guide
 *       §3.1 Powerup sequence  → XOSCEN, 500 ms, ENABLE, 110 ms.
 *       §3.2 2-wire access     → read order 0x0A..0x0F,0x00..0x09 (wrap),
 *                                write order 0x02..0x0F (wrap), no reg addr.
 *       §6.1 Channel = (Freq - Bottom) / Spacing.
 *
 * Pinout (AVR128DA28):
 *   PC2 TWI0 SDA (ALT2)  → Si4703 SDIO
 *   PC3 TWI0 SCL (ALT2)  → Si4703 SCLK
 *   PD0 GPIO output      → Si4703 RST
 *   SEN tied to VIO via 10k (selects 2-wire mode on each RST).
 */

#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "Si4703.h"
#include "twi.h"
#include "uart.h"

#define SI4703_ADDR          0x10

enum {
    REG_DEVICEID    = 0x00,
    REG_CHIPID      = 0x01,
    REG_POWERCFG    = 0x02,
    REG_CHANNEL     = 0x03,
    REG_SYSCONFIG1  = 0x04,
    REG_SYSCONFIG2  = 0x05,
    REG_SYSCONFIG3  = 0x06,
    REG_TEST1       = 0x07,
    REG_TEST2       = 0x08,
    REG_BOOTCONFIG  = 0x09,
    REG_STATUSRSSI  = 0x0A,
    REG_READCHAN    = 0x0B,
    REG_RDSA        = 0x0C,
    REG_RDSB        = 0x0D,
    REG_RDSC        = 0x0E,
    REG_RDSD        = 0x0F,
};

#define POWERCFG_DSMUTE   (1u << 15)
#define POWERCFG_DMUTE    (1u << 14)
#define POWERCFG_MONO     (1u << 13)
#define POWERCFG_RDSM     (1u << 11)   /* 0=standard, 1=verbose */
#define POWERCFG_SKMODE   (1u << 10)
#define POWERCFG_SEEKUP   (1u << 9)
#define POWERCFG_SEEK     (1u << 8)
#define POWERCFG_ENABLE   (1u << 0)
#define CHANNEL_TUNE      (1u << 15)
#define SYSCONFIG1_DE     (1u << 11)   /* 1 = 50 us de-emphasis (EU) */
#define SYSCONFIG1_RDS    (1u << 12)
#define TEST1_XOSCEN      (1u << 15)
#define STATUSRSSI_RDSR   (1u << 15)
#define STATUSRSSI_STC    (1u << 14)
#define STATUSRSSI_SF     (1u << 13)   /* Seek Fail / Band Limit */
#define STATUSRSSI_RDSS   (1u << 11)   /* RDS decoder synchronized */
#define STATUSRSSI_ST     (1u << 8)

#define FM_BASE_X10       875u          /* BAND=00 bottom = 87.5 MHz */
#define FM_TOP_X10        1080u         /* 108.0 MHz */

static uint16_t si_regs[16];
static char     rds_ps[9];
static char     rds_rt[65];
static int8_t   rds_rt_ab = -1;        /* previous Radio Text A/B flag */

static void rds_clear_ps(void) {
    for (uint8_t i = 0; i < 8;  i++) rds_ps[i] = ' ';
    rds_ps[8]  = '\0';
}

static void rds_clear_rt(void) {
    for (uint8_t i = 0; i < 64; i++) rds_rt[i] = ' ';
    rds_rt[64] = '\0';
}

static void rds_reset_buffers(void) {
    rds_clear_ps();
    rds_clear_rt();
    rds_rt_ab = -1;
}

/* -------- Si4703 register I/O (AN230 §3.2) ----------------------------- */

/* Reads 32 bytes = 16 registers in order 0x0A..0x0F, 0x00..0x09. */
static bool Si_read_all(void) {
    uint8_t buf[32];
    static const uint8_t order[16] = {
        0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05,
        0x06, 0x07, 0x08, 0x09
    };

    if (!TWI_read(SI4703_ADDR, buf, 32)) return false;
    for (uint8_t i = 0; i < 16; i++) {
        si_regs[order[i]] = ((uint16_t)buf[2*i] << 8) | buf[2*i + 1];
    }
    return true;
}

/* Writes registers 0x02..0x07 (12 bytes), MSB first. */
static bool Si_write_cfg(void) {
    uint8_t buf[12];
    for (uint8_t i = 0; i < 6; i++) {
        uint16_t v = si_regs[REG_POWERCFG + i];
        buf[2*i]     = (uint8_t)(v >> 8);
        buf[2*i + 1] = (uint8_t)(v & 0xFF);
    }
    return TWI_write(SI4703_ADDR, buf, 12);
}

/* -------- Public API ---------------------------------------------------- */

bool Si4703_init(void) {
    /* SDIO (PC2) low as GPIO before RST goes high → selects 2-wire.
     * SEN held high via external pull-up to VIO. */
    PORTD.DIRSET = PIN0_bm;
    PORTD.OUTCLR = PIN0_bm;                    /* RST = 0 */

    PORTC.DIRSET = PIN2_bm;
    PORTC.OUTCLR = PIN2_bm;                    /* SDIO = 0 */
    _delay_ms(1);

    PORTD.OUTSET = PIN0_bm;                    /* RST = 1 → latch mode */
    _delay_ms(1);

    PORTC.DIRCLR = PIN2_bm;                    /* release SDIO to TWI */
    TWI0_init();
    _delay_ms(1);

    /* Step 1: XOSCEN=1, ENABLE still 0. */
    if (!Si_read_all()) return false;
    si_regs[REG_TEST1] |= TEST1_XOSCEN;
    if (!Si_write_cfg()) return false;
    _delay_ms(500);                            /* crystal startup */

    /* Step 2: refresh shadow and write POWERCFG+SYSCONFIG together
     * in a single transaction (PU2CLR pattern). */
    if (!Si_read_all()) return false;

    si_regs[REG_POWERCFG]   = POWERCFG_DSMUTE | POWERCFG_DMUTE |
                              POWERCFG_MONO   | POWERCFG_ENABLE;

    /* SYSCFG1: DE=1 (50us EU). AGC enabled by default. */
    si_regs[REG_SYSCONFIG1] = SYSCONFIG1_DE;

    /* SYSCFG2: SEEKTH=0x10, BAND=00 (87.5–108), SPACE=01 (100 kHz), VOL=15 */
    si_regs[REG_SYSCONFIG2] = (0x10u << 8) | (0u << 6) | (1u << 4) | 15u;

    si_regs[REG_SYSCONFIG3] = 0x0000;

    if (!Si_write_cfg()) return false;
    _delay_ms(60);

    return Si_read_all();
}

bool Si4703_tune(uint16_t freq_x10) {
    uint16_t chan = (freq_x10 - FM_BASE_X10);  /* 100 kHz units == MHz×10 */

    rds_reset_buffers();

    if (!Si_read_all()) return false;

    si_regs[REG_CHANNEL] = CHANNEL_TUNE | (chan & 0x03FF);
    if (!Si_write_cfg()) return false;

    /* Fixed wait (~60 ms typical) before polling STC. */
    _delay_ms(60);

    bool stc_seen = false;
    for (uint16_t t = 0; t < 100; t++) {
        if (!Si_read_all()) return false;
        if (si_regs[REG_STATUSRSSI] & STATUSRSSI_STC) { stc_seen = true; break; }
        _delay_ms(5);
    }

    /* Clear TUNE */
    si_regs[REG_CHANNEL] &= ~CHANNEL_TUNE;
    if (!Si_write_cfg()) return false;

    if (!stc_seen) return false;               /* timeout: crystal/ENABLE/HW */

    for (uint16_t t = 0; t < 100; t++) {
        if (!Si_read_all()) return false;
        if (!(si_regs[REG_STATUSRSSI] & STATUSRSSI_STC)) break;
        _delay_ms(5);
    }
    return true;
}

void Si4703_diag_tune(uint16_t freq_x10) {
    char s[96];
    uint16_t chan = (freq_x10 - FM_BASE_X10);

    Si_read_all();
    snprintf(s, sizeof(s),
             "[diag] pre  POWERCFG=0x%04X CHAN=0x%04X SYSCFG1=0x%04X SYSCFG2=0x%04X\r\n",
             si_regs[REG_POWERCFG], si_regs[REG_CHANNEL],
             si_regs[REG_SYSCONFIG1], si_regs[REG_SYSCONFIG2]);
    UART1_send_string(s);
    snprintf(s, sizeof(s),
             "[diag] pre  TEST1=0x%04X STATUS=0x%04X READCHAN=0x%04X\r\n",
             si_regs[REG_TEST1], si_regs[REG_STATUSRSSI], si_regs[REG_READCHAN]);
    UART1_send_string(s);

    /* Set CHANNEL + TUNE */
    si_regs[REG_CHANNEL] = CHANNEL_TUNE | (chan & 0x03FF);
    snprintf(s, sizeof(s),
             "[diag] writing CHANNEL=0x%04X (chan=%u, freq_x10=%u)\r\n",
             si_regs[REG_CHANNEL], chan, freq_x10);
    UART1_send_string(s);

    if (!Si_write_cfg()) {
        UART1_send_string("[diag] write_cfg FAILED (TWI ack)\r\n");
        return;
    }

    /* Read back immediately to confirm chip stored TUNE bit + chan */
    _delay_ms(2);
    Si_read_all();
    snprintf(s, sizeof(s),
             "[diag] readback CHANNEL=0x%04X (TUNE bit %s, chan=%u)\r\n",
             si_regs[REG_CHANNEL],
             (si_regs[REG_CHANNEL] & CHANNEL_TUNE) ? "SET" : "CLEAR",
             si_regs[REG_CHANNEL] & 0x03FF);
    UART1_send_string(s);

    /* Poll STC, printing STATUSRSSI snapshots every 50 ms for 600 ms total */
    for (uint16_t t = 0; t < 12; t++) {
        _delay_ms(50);
        Si_read_all();
        snprintf(s, sizeof(s),
                 "[diag] t=%u ms  STATUS=0x%04X (STC=%u RSSI=%u)  READCHAN=0x%04X\r\n",
                 (t + 1) * 50, si_regs[REG_STATUSRSSI],
                 (si_regs[REG_STATUSRSSI] & STATUSRSSI_STC) ? 1 : 0,
                 si_regs[REG_STATUSRSSI] & 0x00FF,
                 si_regs[REG_READCHAN]);
        UART1_send_string(s);
        if (si_regs[REG_STATUSRSSI] & STATUSRSSI_STC) break;
    }

    /* Clear TUNE regardless */
    si_regs[REG_CHANNEL] &= ~CHANNEL_TUNE;
    Si_write_cfg();
}

void Si4703_scan(uint8_t rssi_min) {
    char s[80];
    UART1_send_string("[Si4703] scan start\r\n");

    for (uint16_t f = FM_BASE_X10; f <= FM_TOP_X10; f++) {
        if (!Si4703_tune(f)) {
            snprintf(s, sizeof(s), "[scan] %u.%u MHz tune FAIL\r\n", f/10, f%10);
            UART1_send_string(s);
            continue;
        }
        uint8_t rssi = Si4703_rssi();
        uint8_t st   = Si4703_stereo() ? 1 : 0;
        if (rssi >= rssi_min) {
            snprintf(s, sizeof(s),
                     "[scan] %3u.%u MHz  RSSI=%2u  ST=%u\r\n",
                     f/10, f%10, rssi, st);
            UART1_send_string(s);
        }
    }
    UART1_send_string("[Si4703] scan done\r\n");
}

bool Si4703_freq_up(void) {
    if (!Si_read_all()) return false;
    uint16_t f = FM_BASE_X10 + (si_regs[REG_READCHAN] & 0x03FF);
    f = (f >= FM_TOP_X10) ? FM_BASE_X10 : (uint16_t)(f + 1);
    return Si4703_tune(f);
}

bool Si4703_freq_down(void) {
    if (!Si_read_all()) return false;
    uint16_t f = FM_BASE_X10 + (si_regs[REG_READCHAN] & 0x03FF);
    f = (f <= FM_BASE_X10) ? FM_TOP_X10 : (uint16_t)(f - 1);
    return Si4703_tune(f);
}

bool Si4703_seek(bool up) {
    rds_reset_buffers();

    if (!Si_read_all()) return false;

    /* SKMODE=0 (wrap at band edges), SEEKUP per parameter, SEEK=1 */
    uint16_t pc = si_regs[REG_POWERCFG];
    pc &= ~(POWERCFG_SKMODE | POWERCFG_SEEKUP | POWERCFG_SEEK);
    if (up) pc |= POWERCFG_SEEKUP;
    pc |= POWERCFG_SEEK;
    si_regs[REG_POWERCFG] = pc;
    if (!Si_write_cfg()) return false;

    /* SEEK can take much longer than TUNE (scans the band). */
    bool stc_seen = false;
    for (uint16_t t = 0; t < 2000; t++) {
        if (!Si_read_all()) return false;
        if (si_regs[REG_STATUSRSSI] & STATUSRSSI_STC) { stc_seen = true; break; }
        _delay_ms(5);
    }
    bool failed = (si_regs[REG_STATUSRSSI] & STATUSRSSI_SF) != 0;

    /* Clear SEEK */
    si_regs[REG_POWERCFG] &= ~POWERCFG_SEEK;
    if (!Si_write_cfg()) return false;

    for (uint16_t t = 0; t < 100; t++) {
        if (!Si_read_all()) return false;
        if (!(si_regs[REG_STATUSRSSI] & STATUSRSSI_STC)) break;
        _delay_ms(5);
    }
    return stc_seen && !failed;
}

void Si4703_set_volume(uint8_t vol) {
    if (vol > 15) vol = 15;
    if (!Si_read_all()) return;
    si_regs[REG_SYSCONFIG2] = (si_regs[REG_SYSCONFIG2] & ~0x000F) | vol;
    Si_write_cfg();
}

uint8_t Si4703_volume(void) {
    return (uint8_t)(si_regs[REG_SYSCONFIG2] & 0x000F);
}

void Si4703_volume_up(void) {
    uint8_t v = Si4703_volume();
    Si4703_set_volume((v < 15) ? (uint8_t)(v + 1) : 15);
}

void Si4703_volume_down(void) {
    uint8_t v = Si4703_volume();
    Si4703_set_volume((v > 0) ? (uint8_t)(v - 1) : 0);
}

void Si4703_set_rds(bool on) {
    if (!Si_read_all()) return;
    if (on) {
        si_regs[REG_SYSCONFIG1] |=  SYSCONFIG1_RDS;
        si_regs[REG_POWERCFG]   |=  POWERCFG_RDSM;   /* verbose */
    } else {
        si_regs[REG_SYSCONFIG1] &= ~SYSCONFIG1_RDS;
        si_regs[REG_POWERCFG]   &= ~POWERCFG_RDSM;
    }
    Si_write_cfg();
    rds_reset_buffers();
}

bool Si4703_rds_poll(void) {
    if (!Si_read_all()) return false;

    if (!(si_regs[REG_STATUSRSSI] & STATUSRSSI_RDSR)) return false;

    uint16_t blkB = si_regs[REG_RDSB];
    uint16_t blkC = si_regs[REG_RDSC];
    uint16_t blkD = si_regs[REG_RDSD];

    uint8_t group_type = (uint8_t)((blkB >> 12) & 0xF);
    uint8_t version_b  = (uint8_t)((blkB >> 11) & 0x1);

    if (group_type == 0) {
        /* Group 0A/0B: block D carries 2 PS chars; position 0..3 in B[1:0]. */
        uint8_t pos = (uint8_t)(blkB & 0x3);
        char c0 = (char)(blkD >> 8);
        char c1 = (char)(blkD & 0xFF);
        rds_ps[pos * 2 + 0] = (c0 >= 0x20 && c0 < 0x7F) ? c0 : ' ';
        rds_ps[pos * 2 + 1] = (c1 >= 0x20 && c1 < 0x7F) ? c1 : ' ';
    } else if (group_type == 2 && version_b == 0) {
        /* Group 2A: blocks C+D carry 4 RT chars; segment 0..15 in B[3:0].
         * Bit 4 of B is the text A/B flag: when it toggles the station
         * is sending a new RT string (e.g. new song) — wipe the buffer. */
        uint8_t seg = (uint8_t)(blkB & 0xF);
        int8_t ab  = (int8_t)((blkB >> 4) & 0x1);
        if (rds_rt_ab != ab) { rds_clear_rt(); rds_rt_ab = ab; }
        char c[4] = {
            (char)(blkC >> 8), (char)(blkC & 0xFF),
            (char)(blkD >> 8), (char)(blkD & 0xFF)
        };
        for (uint8_t i = 0; i < 4; i++) {
            rds_rt[seg * 4 + i] = (c[i] >= 0x20 && c[i] < 0x7F) ? c[i] : ' ';
        }
    }
    return true;
}

const char *Si4703_rds_ps(void) { return rds_ps; }
const char *Si4703_rds_rt(void) { return rds_rt; }

bool Si4703_rds_synced(void) {
    return (si_regs[REG_STATUSRSSI] & STATUSRSSI_RDSS) != 0;
}

uint8_t Si4703_rds_blera(void) {
    return (uint8_t)((si_regs[REG_STATUSRSSI] >> 9) & 0x3);
}

bool Si4703_refresh(void)        { return Si_read_all(); }
uint16_t Si4703_device_id(void)  { return si_regs[REG_DEVICEID]; }
uint16_t Si4703_chip_id(void)    { return si_regs[REG_CHIPID]; }
uint16_t Si4703_freq_x10(void)   { return FM_BASE_X10 + (si_regs[REG_READCHAN] & 0x03FF); }
uint8_t  Si4703_rssi(void)       { return (uint8_t)(si_regs[REG_STATUSRSSI] & 0x00FF); }
bool     Si4703_stereo(void)     { return (si_regs[REG_STATUSRSSI] & STATUSRSSI_ST) != 0; }
