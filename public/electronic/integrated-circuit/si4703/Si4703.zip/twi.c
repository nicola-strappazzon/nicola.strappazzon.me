/*
 * TWI0 master bare-metal — AVR128DA28.
 *
 *   PC2 SDA (ALT2)
 *   PC3 SCL (ALT2)
 *
 * Baudrate: MBAUD = F_CPU/(2*F_SCL) - 5 = 24M/(2*100k) - 5 = 115.
 */

#include <avr/io.h>
#include "twi.h"

void TWI0_init(void) {
    PORTMUX.TWIROUTEA = 0x02; /* TWI0 → PC2/PC3 */
    TWI0.CTRLA    = TWI_SDAHOLD_50NS_gc;
    TWI0.DUALCTRL = 0x00;
    TWI0.DBGCTRL  = TWI_DBGRUN_bm;
    TWI0.MBAUD    = 115;
    TWI0.MSTATUS  = TWI_RIF_bm | TWI_WIF_bm | TWI_CLKHOLD_bm |
                    TWI_RXACK_bm | TWI_ARBLOST_bm | TWI_BUSERR_bm |
                    TWI_BUSSTATE_IDLE_gc;
    TWI0.MCTRLA   = TWI_ENABLE_bm;
}

bool TWI_write(uint8_t addr, const uint8_t *data, uint16_t len) {
    TWI0.MADDR = (addr << 1) | 0;
    for (uint16_t i = 0; i < len; i++) {
        while (!(TWI0.MSTATUS & TWI_WIF_bm));
        if (TWI0.MSTATUS & (TWI_ARBLOST_bm | TWI_BUSERR_bm)) return false;
        if (TWI0.MSTATUS & TWI_RXACK_bm)                      return false;
        TWI0.MDATA = data[i];
    }
    while (!(TWI0.MSTATUS & TWI_WIF_bm));
    TWI0.MCTRLB = TWI_MCMD_STOP_gc;
    return true;
}

bool TWI_read(uint8_t addr, uint8_t *data, uint16_t len) {
    TWI0.MADDR = (addr << 1) | 1;
    for (uint16_t i = 0; i < len; i++) {
        while (!(TWI0.MSTATUS & TWI_RIF_bm));
        if (TWI0.MSTATUS & (TWI_ARBLOST_bm | TWI_BUSERR_bm)) return false;
        data[i] = TWI0.MDATA;
        if (i < (len - 1)) TWI0.MCTRLB = TWI_MCMD_RECVTRANS_gc;
        else               TWI0.MCTRLB = TWI_ACKACT_NACK_gc | TWI_MCMD_STOP_gc;
    }
    return true;
}
