#include <avr/io.h>
#include "uart.h"

void UART1_init(void) {
    PORTC.DIRSET = PIN0_bm;
    PORTC.DIRCLR = PIN1_bm;
    USART1.BAUD  = (uint16_t)((64UL * F_CPU) / (16UL * 115200UL) + 0.5);
    USART1.CTRLC = USART_CMODE_ASYNCHRONOUS_gc | USART_CHSIZE_8BIT_gc;
    USART1.CTRLB = USART_TXEN_bm | USART_RXEN_bm;
}

void UART1_write(char c) {
    while (!(USART1.STATUS & USART_DREIF_bm));
    USART1.TXDATAL = c;
}

void UART1_send_string(const char *s) {
    while (*s) UART1_write(*s++);
}

bool UART1_rx_available(void) {
    return (USART1.STATUS & USART_RXCIF_bm) != 0;
}

char UART1_read(void) {
    while (!(USART1.STATUS & USART_RXCIF_bm));
    return (char)USART1.RXDATAL;
}
