/*
 * Si4703 FM tuner demo — AVR128DA28.
 *
 * Pinout:
 *   PC0 USART1 TX (115200)
 *   PC1 USART1 RX
 *   PC2 TWI0 SDA  → Si4703 SDIO
 *   PC3 TWI0 SCL  → Si4703 SCLK
 *   PD0 GPIO out  → Si4703 RST
 *
 * UART commands (115200 8N1):
 *   u/U  freq +0.1 MHz
 *   d/D  freq -0.1 MHz
 *   S    seek up
 *   s    seek down
 *   +    volume up
 *   -    volume down
 *   0    show status
 *   r    show RDS (PS + RT)
 *   p    scan band (prints stations with RSSI >= 20)
 *   ?    show help
 */

#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>
#include "uart.h"
#include "Si4703.h"

static void show_help(void) {
    UART1_send_string("\r\n=== Si4703 radio ===\r\n");
    UART1_send_string(" u/U  freq +0.1 MHz\r\n");
    UART1_send_string(" d/D  freq -0.1 MHz\r\n");
    UART1_send_string(" S    seek up\r\n");
    UART1_send_string(" s    seek down\r\n");
    UART1_send_string(" +    volume up\r\n");
    UART1_send_string(" -    volume down\r\n");
    UART1_send_string(" 0    status\r\n");
    UART1_send_string(" r    RDS (PS + RT)\r\n");
    UART1_send_string(" p    scan band\r\n");
    UART1_send_string(" ?    help\r\n");
}

/* Marquee-style RDS display: a single line that updates in place. PS is
 * fixed on the left (station name), RT scrolls horizontally on the right.
 * Stops on key press or after IDLE_TIMEOUT_MS without a new RDS group. */
static void show_rds(void) {
    const uint16_t IDLE_TIMEOUT_MS = 5000;
    const uint8_t  WINDOW   = 32;          /* visible RT chars */
    const uint8_t  FRAME_MS = 200;         /* scroll step interval */
    uint16_t idle_ms = 0;
    uint8_t  offset  = 0;
    char     line[80];
    char     window[33];                   /* WINDOW + null */

    UART1_send_string("\r\n[RDS] marquee (any key stops)\r\n");

    snprintf(line, sizeof(line),
             "[RDS] sync=%u BLERA=%u RSSI=%u\r\n",
             Si4703_rds_synced() ? 1 : 0,
             Si4703_rds_blera(),
             Si4703_rssi());
    UART1_send_string(line);

    while (idle_ms < IDLE_TIMEOUT_MS) {
        /* Poll and abort-check across the frame interval. */
        for (uint8_t t = 0; t < FRAME_MS / 10; t++) {
            if (UART1_rx_available()) {
                UART1_read();
                UART1_send_string("\r\n[RDS] stopped\r\n");
                return;
            }
            if (Si4703_rds_poll()) idle_ms = 0;
            _delay_ms(10);
        }
        idle_ms += FRAME_MS;

        /* Render: PS fixed, scrolling window into RT (cyclic). */
        const char *rt = Si4703_rds_rt();
        for (uint8_t i = 0; i < WINDOW; i++) {
            window[i] = rt[(offset + i) % 64];
        }
        window[WINDOW] = '\0';

        snprintf(line, sizeof(line), "\r %-8s | %s ", Si4703_rds_ps(), window);
        UART1_send_string(line);
        offset = (uint8_t)((offset + 1) % 64);
    }

    UART1_send_string("\r\n[RDS] stopped (idle)\r\n");
}

static void show_status(void) {
    char s[80];
    Si4703_refresh();
    uint16_t f = Si4703_freq_x10();
    snprintf(s, sizeof(s),
             "[Si4703] %u.%u MHz  RSSI=%u  ST=%u  VOL=%u\r\n",
             f / 10, f % 10,
             Si4703_rssi(),
             Si4703_stereo() ? 1 : 0,
             Si4703_volume());
    UART1_send_string(s);
}

int main(void) {
    char s[80];

    CCP = CCP_IOREG_gc;
    CLKCTRL.OSCHFCTRLA = CLKCTRL_FRQSEL_24M_gc;

    UART1_init();
    UART1_send_string("[Si4703] boot\r\n");

    if (!Si4703_init()) {
        UART1_send_string("[Si4703] init FAILED\r\n");
        while (1);
    }

    snprintf(s, sizeof(s),
             "[Si4703] DeviceID=0x%04X ChipID=0x%04X\r\n",
             Si4703_device_id(), Si4703_chip_id());
    UART1_send_string(s);

    /* Initial tune: change to a frequency you receive well. */
    if (!Si4703_tune(883)) {
        UART1_send_string("[Si4703] tune FAILED\r\n");
    }

    Si4703_set_rds(true);

    show_status();
    show_help();

    while (1) {
        Si4703_rds_poll();

        if (!UART1_rx_available()) continue;

        char c = UART1_read();
        switch (c) {
            case 'u': case 'U': Si4703_freq_up();    show_status(); break;
            case 'd': case 'D': Si4703_freq_down();  show_status(); break;
            case 'S':           Si4703_seek(true);   show_status(); break;
            case 's':           Si4703_seek(false);  show_status(); break;
            case '+':           Si4703_volume_up();  show_status(); break;
            case '-':           Si4703_volume_down();show_status(); break;
            case '0':           show_status();                      break;
            case 'r':           show_rds();                         break;
            case 'p':           Si4703_scan(10);    show_status();  break;
            case '?':           show_help();                        break;
            case '\r': case '\n':                                   break;
            default:            UART1_send_string("? (try '?')\r\n"); break;
        }
    }
}
